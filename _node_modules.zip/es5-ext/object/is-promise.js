"use strict";

// In next major this check will also confirm on promise constructor
module.exports = require("./is-thenable");
